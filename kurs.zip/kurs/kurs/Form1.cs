﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace kurs
{
    public partial class Form1 : Form
    {
        private OleDbConnection connection;
        private OleDbDataAdapter adapter;
        private DataSet dataSet;
        private TextBox textBoxID;
        private TextBox textBoxFilm;
        private TextBox textBoxGenre;
        private TextBox textBoxHall;
        private TextBox textBoxCountry;
        private DateTimePicker dateTimePickerRelease;
        private Button buttonAdd;
        private Button buttonDelete;
        private Button buttonUpdate;
        private Button buttonSearch;
        private DataGridView dataGridView1;
        private TextBox textBoxSearchID;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Подключение к базе данных Access
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\student\Desktop\kakashi ip 31 chempion\kurs\kurs\bin\Debug\dbtk.accdb;Persist Security Info=False;";
            connection = new OleDbConnection(connectionString);

            // Создание DataSet и привязка к DataGridView
            dataSet = new DataSet();
            string query = "SELECT * FROM Customers";
            adapter = new OleDbDataAdapter(query, connection);
            adapter.Fill(dataSet, "Customers");
            dataGridView1 = new DataGridView();
            dataGridView1.DataSource = dataSet.Tables["Customers"];

            // Добавление элементов на форму
            Label labelID = new Label();
            labelID.Text = "ID:";
            labelID.Location = new Point(10, 10);
            labelID.AutoSize = true;
            this.Controls.Add(labelID);

            textBoxID = new TextBox();
            textBoxID.Location = new Point(40, 10);
            textBoxID.Size = new Size(100, 20);
            this.Controls.Add(textBoxID);

            textBoxSearchID = new TextBox();
            textBoxSearchID.Location = new Point(150, 10);
            textBoxSearchID.Size = new Size(100, 20);
            this.Controls.Add(textBoxSearchID);

            buttonSearch = new Button();
            buttonSearch.Text = "Поиск";
            buttonSearch.Location = new Point(260, 10);
            buttonSearch.Click += ButtonSearch_Click;
            this.Controls.Add(buttonSearch);

            Label labelFilm = new Label();
            labelFilm.Text = "Фильм:";
            labelFilm.Location = new Point(10, 40);
            labelFilm.AutoSize = true;
            this.Controls.Add(labelFilm);

            textBoxFilm = new TextBox();
            textBoxFilm.Location = new Point(60, 40);
            textBoxFilm.Size = new Size(200, 20);
            this.Controls.Add(textBoxFilm);

            Label labelGenre = new Label();
            labelGenre.Text = "Жанр:";
            labelGenre.Location = new Point(10, 70);
            labelGenre.AutoSize = true;
            this.Controls.Add(labelGenre);

            textBoxGenre = new TextBox();
            textBoxGenre.Location = new Point(60, 70);
            textBoxGenre.Size = new Size(150, 20);
            this.Controls.Add(textBoxGenre);

            Label labelHall = new Label();
            labelHall.Text = "Зал:";
            labelHall.Location = new Point(220, 70);
            labelHall.AutoSize = true;
            this.Controls.Add(labelHall);

            textBoxHall = new TextBox();
            textBoxHall.Location = new Point(260, 70);
            textBoxHall.Size = new Size(100, 20);
            this.Controls.Add(textBoxHall);

            Label labelCountry = new Label();
            labelCountry.Text = "Страна:";
            labelCountry.Location = new Point(10, 100);
            labelCountry.AutoSize = true;
            this.Controls.Add(labelCountry);

            textBoxCountry = new TextBox();
            textBoxCountry.Location = new Point(80, 100);
            textBoxCountry.Size = new Size(150, 20);
            this.Controls.Add(textBoxCountry);

            Label labelRelease = new Label();
            labelRelease.Text = "Релиз:";
            labelRelease.Location = new Point(240, 100);
            labelRelease.AutoSize = true;
            this.Controls.Add(labelRelease);

            dateTimePickerRelease = new DateTimePicker();
            dateTimePickerRelease.Location = new Point(290, 100);
            this.Controls.Add(dateTimePickerRelease);

            buttonAdd = new Button();
            buttonAdd.Text = "Добавить";
            buttonAdd.Location = new Point(10, 130);
            buttonAdd.Click += ButtonAdd_Click;
            this.Controls.Add(buttonAdd);

            buttonDelete = new Button();
            buttonDelete.Text = "Удалить";
            buttonDelete.Location = new Point(100, 130);
            buttonDelete.Click += ButtonDelete_Click;
            this.Controls.Add(buttonDelete);

            buttonUpdate = new Button();
            buttonUpdate.Text = "Изменить";
            buttonUpdate.Location = new Point(190, 130);
            buttonUpdate.Click += ButtonUpdate_Click;
            this.Controls.Add(buttonUpdate);

            dataGridView1.Location = new Point(10, 160);
            dataGridView1.Size = new Size(700, 300);
            this.Controls.Add(dataGridView1);
        }

        private void ButtonSearch_Click(object sender, EventArgs e)
        {
            // Поиск записи по ID
            int id = int.Parse(textBoxSearchID.Text);
            string query = $"SELECT * FROM Customers WHERE ID = {id}";
            OleDbCommand command = new OleDbCommand(query, connection);

            try
            {
                connection.Open();
                OleDbDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    // Заполнение текстовых полей значениями из найденной записи
                    textBoxID.Text = reader["ID"].ToString();
                    textBoxFilm.Text = reader["Фильм"].ToString();
                    textBoxGenre.Text = reader["Жанр"].ToString();
                    textBoxHall.Text = reader["Зал"].ToString();
                    textBoxCountry.Text = reader["Страна"].ToString();
                    dateTimePickerRelease.Value = DateTime.Parse(reader["Релиз"].ToString());
                }
                else
                {
                    MessageBox.Show("Запись не найдена!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void ButtonAdd_Click(object sender, EventArgs e)
        {
            // Получение значений из элементов формы
            int id = int.Parse(textBoxID.Text);
            string film = textBoxFilm.Text;
            string genre = textBoxGenre.Text;
            string hall = textBoxHall.Text;
            string country = textBoxCountry.Text;
            DateTime release = dateTimePickerRelease.Value;

            // Добавление новой записи в таблицу Customers
            string query = "INSERT INTO Customers (ID, Фильм, Жанр, Зал, Страна, Релиз) VALUES (@ID, @Film, @Genre, @Hall, @Country, @Release)";
            OleDbCommand command = new OleDbCommand(query, connection);
            command.Parameters.AddWithValue("@ID", id);
            command.Parameters.AddWithValue("@Film", film);
            command.Parameters.AddWithValue("@Genre", genre);
            command.Parameters.AddWithValue("@Hall", hall);
            command.Parameters.AddWithValue("@Country", country);
            command.Parameters.AddWithValue("@Release", release);

            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Запись успешно добавлена!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            // Обновление DataGridView
            dataSet.Tables["Customers"].Clear();
            adapter.Fill(dataSet, "Customers");
        }

        private void ButtonDelete_Click(object sender, EventArgs e)
        {
            // Получение выбранной строки из DataGridView
            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            int id = (int)selectedRow.Cells["ID"].Value;

            // Удаление записи из таблицы Customers
            string query = "DELETE FROM Customers WHERE ID = @ID";
            OleDbCommand command = new OleDbCommand(query, connection);
            command.Parameters.AddWithValue("@ID", id);

            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Запись успешно удалена!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            // Обновление DataGridView
            dataSet.Tables["Customers"].Clear();
            adapter.Fill(dataSet, "Customers");
        }

        private void ButtonUpdate_Click(object sender, EventArgs e)
        {
            // Получение выбранной строки из DataGridView
            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            int id = (int)selectedRow.Cells["ID"].Value;

            // Получение новых значений из элементов формы
            string film = textBoxFilm.Text;
            string genre = textBoxGenre.Text;
            string hall = textBoxHall.Text;
            string country = textBoxCountry.Text;
            DateTime release = dateTimePickerRelease.Value;

            // Обновление записи в таблице Customers
            string query = "UPDATE Customers SET Фильм = @Film, Жанр = @Genre, Зал = @Hall, Страна = @Country, Релиз = @Release WHERE ID = @ID";
            OleDbCommand command = new OleDbCommand(query, connection);
            command.Parameters.AddWithValue("@Film", film);
            command.Parameters.AddWithValue("@Genre", genre);
            command.Parameters.AddWithValue("@Hall", hall);
            command.Parameters.AddWithValue("@Country", country);
            command.Parameters.AddWithValue("@Release", release);
            command.Parameters.AddWithValue("@ID", id);

            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Запись успешно изменена!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            // Обновление DataGridView
            dataSet.Tables["Customers"].Clear();
            adapter.Fill(dataSet, "Customers");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}