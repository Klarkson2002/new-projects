﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace kur
{
    public partial class Form1 : Form
    {
        OleDbConnection connection;
        OleDbCommand command;
        OleDbDataAdapter adapter;
        DataTable table;

        private TextBox idTextBox;
        private DateTimePicker visitDatePicker;
        private DateTimePicker visitTimePicker;
        private TextBox serviceTextBox;
        private TextBox staffTextBox;
        private DataGridView clientDataGridView;
        private Button addButton;
        private Button updateButton;
        private Button deleteButton;
        private Label idLabel;
        private Label visitDateLabel;
        private Label visitTimeLabel;
        private Label serviceLabel;
        private Label staffLabel;

        public Form1()
        {
            InitializeComponent();
            InitializeDatabaseConnection();
            InitializeUIElements();
            LoadData();
        }

        private void InitializeDatabaseConnection()
        {
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\glnnn\OneDrive\Рабочий стол\3 курс\3.2\БД\kur\kur\bin\Debug\zdb.accdb";
            connection = new OleDbConnection(connectionString);
            command = connection.CreateCommand();
        }

        private void InitializeUIElements()
        {
            idLabel = new Label();
            idLabel.Text = "ID:";
            idLabel.Location = new Point(20, 50);
            this.Controls.Add(idLabel);

            visitDateLabel = new Label();
            visitDateLabel.Text = "Дата посещения:";
            visitDateLabel.Location = new Point(20, 80);
            this.Controls.Add(visitDateLabel);

            visitTimeLabel = new Label();
            visitTimeLabel.Text = "Время посещения:";
            visitTimeLabel.Location = new Point(20, 110);
            this.Controls.Add(visitTimeLabel);

            serviceLabel = new Label();
            serviceLabel.Text = "Услуга:";
            serviceLabel.Location = new Point(20, 140);
            this.Controls.Add(serviceLabel);

            staffLabel = new Label();
            staffLabel.Text = "Персонал:";
            staffLabel.Location = new Point(20, 170);
            this.Controls.Add(staffLabel);

            idTextBox = new TextBox();
            idTextBox.Location = new Point(120, 50); // Moved 20 pixels to the right
            idTextBox.Size = new Size(200, 20);
            this.Controls.Add(idTextBox);

            visitDatePicker = new DateTimePicker();
            visitDatePicker.Location = new Point(120, 80); // Moved 20 pixels to the right
            visitDatePicker.Size = new Size(200, 20);
            this.Controls.Add(visitDatePicker);

            visitTimePicker = new DateTimePicker();
            visitTimePicker.Format = DateTimePickerFormat.Time;
            visitTimePicker.ShowUpDown = true;
            visitTimePicker.Location = new Point(120, 110); // Moved 20 pixels to the right
            visitTimePicker.Size = new Size(200, 20);
            this.Controls.Add(visitTimePicker);

            serviceTextBox = new TextBox();
            serviceTextBox.Location = new Point(120, 140); // Moved 20 pixels to the right
            serviceTextBox.Size = new Size(200, 20);
            this.Controls.Add(serviceTextBox);

            staffTextBox = new TextBox();
            staffTextBox.Location = new Point(120, 170); // Moved 20 pixels to the right
            staffTextBox.Size = new Size(200, 20);
            this.Controls.Add(staffTextBox);

            clientDataGridView = new DataGridView();
            clientDataGridView.Location = new Point(450, 50);
            clientDataGridView.Size = new Size(547, 200);
            this.Controls.Add(clientDataGridView);

            addButton = new Button();
            addButton.Text = "Добавить";
            addButton.Location = new Point(450, 260);
            addButton.Size = new Size(100, 30);
            addButton.Click += AddToDatabase;
            this.Controls.Add(addButton);

            updateButton = new Button();
            updateButton.Text = "Изменить";
            updateButton.Location = new Point(560, 260);
            updateButton.Size = new Size(100, 30);
            updateButton.Click += UpdateDatabase;
            this.Controls.Add(updateButton);

            deleteButton = new Button();
            deleteButton.Text = "Удалить";
            deleteButton.Location = new Point(670, 260);
            deleteButton.Size = new Size(100, 30);
            deleteButton.Click += DeleteFromDatabase;
            this.Controls.Add(deleteButton);
        }

        private void LoadData()
        {
            connection.Open();
            adapter = new OleDbDataAdapter("SELECT * FROM client", connection);
            table = new DataTable();
            adapter.Fill(table);
            clientDataGridView.DataSource = table;
            connection.Close();
        }

        private void AddToDatabase(object sender, EventArgs e)
        {
            string id = idTextBox.Text;
            string visitDate = visitDatePicker.Value.ToString("yyyy-MM-dd");
            string visitTime = visitTimePicker.Value.ToString("HH:mm:ss");
            string service = serviceTextBox.Text;
            string staff = staffTextBox.Text;

            connection.Open();
            command.CommandText = "INSERT INTO client (ID, [Дата посещения], [Время посещения], [Услуга], [Персонал]) VALUES ('" + id + "', '" + visitDate + "', '" + visitTime + "', '" + service + "', '" + staff + "')";
            command.ExecuteNonQuery();
            connection.Close();

            LoadData();
            ClearInputFields();
            MessageBox.Show("Информация успешно добавлена в базу данных!");
        }

        private void UpdateDatabase(object sender, EventArgs e)
        {
            if (clientDataGridView.SelectedRows.Count > 0)
            {
                int id = Convert.ToInt32(clientDataGridView.SelectedRows[0].Cells[0].Value);
                string visitDate = visitDatePicker.Value.ToString("yyyy-MM-dd");
                string visitTime = visitTimePicker.Value.ToString("HH:mm:ss");
                string service = serviceTextBox.Text;
                string staff = staffTextBox.Text;

                connection.Open();
                command.CommandText = "UPDATE client SET [Дата посещения]='" + visitDate + "', [Время посещения]='" + visitTime + "', [Услуга]='" + service + "', [Персонал]='" + staff + "' WHERE ID=" + id;
                command.ExecuteNonQuery();
                connection.Close();

                LoadData();
                ClearInputFields();
                MessageBox.Show("Информация успешно обновлена в базе данных!");
            }
            else
            {
                MessageBox.Show("Выберите строку для обновления!");
            }
        }

        private void DeleteFromDatabase(object sender, EventArgs e)
        {
            if (clientDataGridView.SelectedRows.Count > 0)
            {
                int id = Convert.ToInt32(clientDataGridView.SelectedRows[0].Cells[0].Value);

                connection.Open();
                command.CommandText = "DELETE FROM client WHERE ID=" + id;
                command.ExecuteNonQuery();
                connection.Close();

                LoadData();
                ClearInputFields();
                MessageBox.Show("Информация успешно удалена из базы данных!");
            }
            else
            {
                MessageBox.Show("Выберите строку для удаления!");
            }
        }

        private void ClearInputFields()
        {
            idTextBox.Clear();
            visitDatePicker.Value = DateTime.Now;
            visitTimePicker.Value = DateTime.Now;
            serviceTextBox.Clear();
            staffTextBox.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Additional setup if needed
        }
    }
}